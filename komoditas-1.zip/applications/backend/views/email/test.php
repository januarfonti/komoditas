<?php $this->load->view('email/_header'); ?>

<p>This is a test email.</p>

<?php $this->load->view('email/_footer'); ?>