<?php $this->load->view('_partial/head'); ?>
    
    {body}

<?php $this->load->view('_partial/foot'); ?>