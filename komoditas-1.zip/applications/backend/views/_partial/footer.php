
<footer class="main-footer">
	<strong>Copyright © 2015 <a href="<?php echo base_url(); ?>">SIKOMPA</a>.</strong> All rights reserved.
</footer>