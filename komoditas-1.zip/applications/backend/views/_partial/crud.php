
<?php if ( !empty($crud_note) ) echo $crud_note; ?>

<?php if ( !empty($crud_data) ) echo $crud_data->output; ?>
