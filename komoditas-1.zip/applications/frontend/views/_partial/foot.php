<!-- Footer
      =================================================== -->
      <footer class="footer-block">
          <div class="container cont-top clearfix">
              <div class="row">
                  <div class="col-md-3 brand-col brand-center">
                      <div class="vcenter">
                          <a class="vcenter-this" href="<?php echo base_url(); ?>">
                              <img src="<?php echo base_url('assets/dist/images/logo.png'); ?>" alt="logo"/>
                          </a>
                      </div>
                  </div>
                  <div class="col-md-9 links-col">
                      <div class="row-fluid">
                          <div class="col-xs-12 col-sm-12 col-md-12">
                              <h5>Tentang SIKOMPA</h5>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis auctor justo et sagittis dictum. Ut pharetra tellus at dolor malesuada, vitae malesuada urna rhoncus. Sed fermentum augue odio, sed semper mauris vestibulum ut. Aenean fringilla tellus fringilla lacus suscipit, ut molestie diam faucibus. Duis consectetur tempus risus, eget egestas ex congue pellentesque. Cras eu ultrices purus, ac ornare eros. Ut tempus est ut purus vehicula, at venenatis ipsum auctor. Vivamus cursus lacinia eros, a sodales magna commodo vitae. Morbi facilisis urna eget nisi sodales, a ullamcorper nibh vulputate. In sed dolor nec nunc convallis eleifend sit amet quis nulla. Cras eleifend eros quis finibus ullamcorper. Duis vel molestie diam.</p>
                                  <ul class="hlinks hlinks-icons color-icons-borders color-icons-bg color-icons-hovered">
                                    <li><a href="#"><i class="icon fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="icon fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="icon fa fa-rss"></i></a></li>
                                    <li><a href="#"><i class="icon fa fa-google-plus"></i></a></li>
                                    <li><a href="#"><i class="icon fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="icon fa fa-youtube"></i></a></li>
                                  </ul>
                            </div>
                        </div>
                  </div>
              </div>
          </div>
        
        
        <!-- Bottom -->
        <div class="footer-bottom invert-colors bcolor-bg">
        
          <!-- Container -->
          <div class="container">
              <span class="copy-text pull-right">&copy; 2015 SIKOMPA - Sistem Komoditas Harga Pangan</span>
          </div>
          <!-- /Container -->
          
        </div>
        <!-- /Bottom -->
        
      </footer>
      <!-- /Footer
      =================================================== -->
      
     
      
    </div>
    <!-- /Page Wrapper
    ++++++++++++++++++++++++++++++++++++++++++++++ -->

 
  </body>
</html>
