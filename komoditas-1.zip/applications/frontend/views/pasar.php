<?php 
foreach ($data_pasar as $row) 
{
	echo $row->id_pasar;
	echo $row->nama_pasar;
}