<?php

/**
 * https://github.com/jamierumbelow/codeigniter-base-model
 */
class Backend_user_model extends MY_Model
{
	public $_table = 'backend_users';
	public $return_type = 'array';
}