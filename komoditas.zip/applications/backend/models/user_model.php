<?php

/**
 * https://github.com/jamierumbelow/codeigniter-base-model
 */
class User_model extends MY_Model
{
	public $_table = 'users';
	public $return_type = 'array';
}