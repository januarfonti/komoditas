<?php if ( !empty($back_url) ) { ?>
	<hr/>
	<?php echo btn('Back', $back_url, 'reply'); ?>
<?php } ?>