
<div class="alert alert-success">
	<p>Click below to view sub-pages</p>
	<ul>
		<li><a href="<?php echo site_url('example/demo/1'); ?>">Demo 1</a></li>
		<li><a href="<?php echo site_url('example/demo/2'); ?>">Demo 2</a></li>
		<li><a href="<?php echo site_url('example/demo/3'); ?>">Demo 3</a></li>
	</ul>
</div>
