<?php $this->load->view('_partial/head'); ?>

	

		<?php $this->load->view('_partial/header'); ?>
		
	
			{body}
	

<?php $this->load->view('_partial/foot'); ?>