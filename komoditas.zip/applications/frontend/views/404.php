
<p>Please <a href="<?php echo site_url(); ?>">click here</a> to go back to homepage.</p>