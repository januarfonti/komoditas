<div class="content-block">
    <div class="container cont-pad-t-sm">
        <?php echo $data_kontak->kontak; ?>
    </div>
</div>