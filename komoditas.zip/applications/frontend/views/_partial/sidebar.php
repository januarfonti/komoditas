
<div class="alert alert-info">
	This is the sidebar content.
</div>
